#!/bin/bash
ssh $1 $2