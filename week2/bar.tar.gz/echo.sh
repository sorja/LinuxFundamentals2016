#!/bin/bash
# script that passes args to echo ?_?
echo "$@"