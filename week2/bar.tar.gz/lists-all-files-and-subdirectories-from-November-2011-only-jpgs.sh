#!/bin/bash
# A small script to count all jpgs
ls -R /cs/home/tkt_cam/public_html/2011/11/ | grep jpg | wc -l