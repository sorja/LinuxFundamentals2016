#!/bin/bash
# A small script that counts the items in your ~ (home) directory
ls ~ | wc -l