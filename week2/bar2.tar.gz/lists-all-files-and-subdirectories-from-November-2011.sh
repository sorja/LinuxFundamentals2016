#!/bin/bash
# A small script to list all subdirs/files recursively
ls -R /cs/home/tkt_cam/public_html/2011/11/