#!/bin/bash
# A small script to list all jpgs recursively
ls -R /cs/home/tkt_cam/public_html/2011/11/ | grep jpg